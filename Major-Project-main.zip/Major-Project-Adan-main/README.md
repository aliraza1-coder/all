Actual Source code is in zip file.....

Read the following instructions carefully.



# Major-Project-Adan
A responsive e-commerce platform using HTML, CSS, JavaScript, Tailwind CSS, React.js, Redux Toolkit, Formik, and Yup. 
The platform should include a landing page, product listings, detailed product pages, a shopping cart, a multi-step checkout process,
an order history page, and an admin panel for managing products and user accounts.


1.Use Redux Toolkit for state management.
2.Implement Formik and Yup for form handling and validation.
3.Ensure the application is fully responsive.
4.Provide a seamless user experience with a clean and modern design.
5.CURD Operation 
6.Rapid Api

Install the code in your PC and run it via VS Code.
In Terminal write this command npm install
In Terminal write this command npm start or npm run dev
